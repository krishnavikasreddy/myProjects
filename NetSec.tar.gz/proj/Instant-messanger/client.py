#!/usr/bin/env python
# -*- coding: utf-8 -*-
import hashlib
import json, base64, socket
import ntpath
import os, sys, os.path
from ConfigParser import SafeConfigParser

import handle_prime_numbers
import helpers




class Client:
    config = SafeConfigParser()
    config.read('main_config.txt')
    salt = config.get('SectionOne', 'Salt')
    hKey = config.get('SectionOne', 'HKey')
    MSG_LEN = config.getint('SectionOne', 'MsgLen')
    generator = config.getint('SectionOne', 'Generator')
    peerPrime = config.getint('SectionOne', 'PeerPrime')
    peerGenerator = config.getint('SectionOne', 'PeerGenerator')

    def __init__(self, ipAddr, port):
        self.serverAddr = ipAddr
        self.port = port
        self.count = 3  # only 3 login attempts are allowed
        self.isAuthenticated = False
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.settimeout(3.0)
        self.peers = {}
        self.DBG = True

        self.serverPublicKey = helpers.getPublicKey('server_public_key.pem')
        if (self.serverPublicKey == -1):
            sys.exit(-1)

    def getSocket(self):
        return self.sock

    def disconnectClient(self):
        if self.isAuthenticated == True:
            msg = "DISCONNECTING:"
            self.send_encrypted_message(msg)

    def login(self):
        while self.count != 0:
            self.count -= 1
            # self.username = raw_input("Please enter your username: ")
            # self.password = raw_input("Please enter your password: ")
            self.username = "Tricia_S"
            self.password = "tricia"
            self.pwdHash = helpers.generateSaltedPasswordHash(Client.hKey, Client.salt, self.password)

            # print self.pwdHash,"ffs"
            # sys.exit()

            if self.DBG is True:
                print "password: %s, pwdHash: %s " % (self.password, self.pwdHash)
            self.isAuthenticated = self.authenticate_me(self.pwdHash)


            if self.isAuthenticated is True:
                print "===============================\n" \
                      " Welcome {}! Happy Chatting!!! \n".format(self.username), \
                    "===============================\n"
                break
            else:
                print " Error!! username or password is invalid, please try again\n"

        if self.count == 0:
            print " Exceeded number of trials...Good bye!"
            sys.exit(-1)
        else:
            return self.isAuthenticated

    def send_message(self, msg, addr, port):
        ret = False
        try:
            self.sock.sendto(msg, (addr, port))
            ret = True
        except Exception, e:
            print "send message failed: ", e
        return ret

    def receive_response(self):

        data = None
        address = None
        try:

            data, address = self.sock.recvfrom(Client.MSG_LEN)
        except socket.timeout, e:
            address = None
        return data

    def solve_challenge(self, challenge, num):

        if self.DBG:
            print " challenge: %s, num: %s" % (challenge, num)

        response = int(helpers.generateKeyHash(str(num)), 16)
        while response != challenge:
            num += 1
            response = int(helpers.generateKeyHash(str(num)), 16)
            # print " challenge: %x, hash: %x" % (challenge, response)

        return num

    def authenticate_me(self, pwdHash):
        # print "authenticate with chat server and set up session key"
        ret = False
        if self.serverPublicKey is not None:
            # step 1: send authentication message
            a = helpers.generateRandomKey(16)
            # retrieve the safe prime for the user
            p = handle_prime_numbers.genp(self.username, self.password)

            client_contribution = pow(Client.generator, int(a.encode('hex'), 16), p)
            msg = "AUTH:{}:{}".format(self.username, client_contribution)

            if not self.send_message(msg, self.serverAddr, self.port):
                return ret

            # step 2: receive challenge and starting number
            serverResponse = self.receive_response()
            if (serverResponse is None):
                return ret

            challengeAndStartingNum = serverResponse.split(":")
            challenge = int(challengeAndStartingNum[0], 16)
            startingNum = int(challengeAndStartingNum[1])


            challenge_response = self.solve_challenge(challenge, startingNum)

            # step 4: generate client contribution (2^a mod p) and send challenge response,
            # client user name and contribution to server Note: no need to encrypt because eavesdropper
            # cannot compute 2^W mod p

            msg = "CONTRIBUTION:" + str(challenge_response) + ":" + self.username + ":" + str(client_contribution)
            # msg = helpers.encryptUsingPublicKey(self.serverPublicKey, msg)
            if not self.send_message(msg, self.serverAddr, self.port):
                return ret


            # step 5: receive server contribution and shared key hash
            serverResponse = self.receive_response()
            if (serverResponse is None):
                print "failed to receive response from server"
                return ret

            if self.DBG:
                print "STEP 5 : RECEIVED : ",serverResponse
            serverContributionAndHash = serverResponse.split(":")
            serverContribution = serverContributionAndHash[0]
            serverSessionKeyHash = serverContributionAndHash[1]

            # step 6: calculate session key and hash
            W = pwdHash
            # 2^ab mod p
            sharedKey1 = helpers.generateSecretKey(int(serverContribution),
                                                     int(a.encode('hex'), 16), p)
            # 2^bW mod p
            sharedKey2 = helpers.generateSecretKey(int(serverContribution), int(W, 16), p)
            sessionKey = (str(sharedKey1) + str(sharedKey2))[0:16]
            if self.DBG:
                print "sharedKey1: %s, sharedKey2: %s, sessionKey: %s, len: %d" % \
                      (sharedKey1, sharedKey2, sessionKey, len(sessionKey))

            # HASH(2^ab mod p, 2^bW modp)
            sessionKeyHash = helpers.generateKeyHash(sessionKey)
            if (serverSessionKeyHash == sessionKeyHash):
                self.sessionKey = sessionKey
                self.sessionID = serverContributionAndHash[2]
                if self.DBG:
                    print"====== session keys match!! sessionID %s, len: %d " % \
                         (self.sessionID, len(self.sessionID))

                    # step 7: send hash of encrypted session key and public key to server
                self.clientPrivateKey, self.clientPublicKey = helpers.generatePublicPrivateKeys()
                validateServer = int(helpers.generateRandomKey(16).encode("hex"), 16)

                # msg = "VALIDATE:" + sessionKeyHash + ":" + self.clientPublicKey + ":" + validateServer
                msg = "VALIDATE:" + sessionKeyHash + ":" + str(validateServer) + ":" + self.clientPublicKey

                msg = helpers.encyptUsingSymmetricKey(self.sessionKey, self.sessionID,
                                                        msg)
                if not self.send_message(msg, self.serverAddr, self.port):
                    return ret

                # server signals that client has been fully authenticated
                response = self.receive_response()
                if response is None:
                    print "Error!!! didn't receive response from server"
                    return ret
                response = helpers.decryptUsingSymetricKey(self.sessionKey, self.sessionID, response)
                response = response.split(":")
                if self.DBG is True:
                    print "validateServer: %s, serverResponse: %s" % (str(validateServer),
                                                                      response[1])
                if response[0] == "ACKNOWLEDGE" and \
                        int(validateServer + 1 == int(response[1])):
                    ret = True

                    # End of authentication with server.

        return ret

if __name__ == "__main__":

    c = Client("127.0.1.1",9060)
    c.login()