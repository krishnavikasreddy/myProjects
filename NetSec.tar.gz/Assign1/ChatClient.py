
import socket
import threading
import json
import os
import sys



class Client():
    #Client connects to the server with a GREETING MESSAGE


    def __init__(self,server_addr,server_port):
        self.HOST=self.get_host_name() #host name
        self.SERVER_ADDR=server_addr #server address to connect
        self.SERVER_PORT=server_port #server port to connect
        self.socket=self.create_UDP_connection() #socket
        self.MESSAGES={"greet":"GREETINGS","msg":"MESSAGES","incoming":"INCOMING"}#Type of Messages



    def create_UDP_connection(self):
        #create a socket with proper exception handling
        try:
            sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        except socket.error, msg :
            print 'Failed to create socket. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
            sock=None
            exit_system()
        finally:
            return sock


    def get_host_name(self):
        #Host name for with proper exception handling
        try:
            host_name=socket.gethostname()
        except socket.herror,msg:
            print 'Failed to get Host Name. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
            host_name=None
            exit_system()
        finally:
            return host_name

    def listen_for_messages(self):
        #Listen for Incoming messages from  the server
        #This has its own thread so that it does not block other process
        soc=self.socket
        while 1:
            data = soc.recvfrom(1024)
            #JSON to send and recv data
            #type,address,port,msg
            try:
                reply = json.loads(data[0])
            except TypeError,emsg:
                print "TypeError"+emsg
                exit_system()
            #check if the message is incoming if yes then print it
            if reply["type"]==self.MESSAGES["incoming"]:
                print '\n<From ' +reply["address"]+":"+str(reply["port"])+">: "+str(reply["msg"])


    def send_message_to_server(self):
        s = self.socket #socket created at the beginnig

        #Receiving is a blocking operation
        #So start a new thread so that it does not interrupt sending messages
        thread_to_recv_message=threading.Thread(target=self.listen_for_messages)
        thread_to_recv_message.start()

        #Send a Greetings Message
        try:
            s.sendto(json.dumps({"type":self.MESSAGES["greet"],"msg":"Hello World"}),(self.SERVER_ADDR,self.SERVER_PORT))
        except socket.error,msg:
            print 'Error Code : ' + str(msg[0]) + ' Message: ' + msg[1]
            s.close()
            exit_system()
        #Send a message to Server
        while 1:
            try:
                msg = raw_input('Enter message to send : ')

                try :
                    s.sendto(json.dumps({"type":self.MESSAGES["msg"],"msg":msg}), (self.SERVER_ADDR,self.SERVER_PORT))

                except socket.error, msg:
                    print 'Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
                    s.close()
                    exit_system()
            except IOError,msg:
                print "IO Error"+msg
                s.close()
                exit_system()






#Exit system handle multiple cases
#Global function so that it can be Used any where
def exit_system():
    print "Exiting Now"
    try:
        sys.exit(0)#some systems dont support sys.exit especially when access to sys module is blocked
    except:
        os._exit(0)

#Conditions for port
#They cannot be negative and they cannot be out of known bounds
def check_ports(port):

    try:
        port=int(port)
    except:
        print "Port not an Integer"
        exit_system()
    if port < 0:
        print "Port cannot be Negative Number"
        exit_system()
    elif port > 65535:
        print "Port is out of bounds"
        exit_system()


if __name__ == "__main__":

    args={}
    args_paras=[1,3]

    if len(sys.argv) < 5:
        print "Not enough arguments"
    else:
        for i in args_paras:
            args[sys.argv[i]]=sys.argv[i+1]

        try:
            check_ports(args["-sp"])

            client=Client(args["-sip"],int(args["-sp"]))
            print "Connection on ",client.SERVER_ADDR,"Port",client.SERVER_PORT
            try:
                client.send_message_to_server()
            except KeyboardInterrupt:
                print "keyboard interrupt"
                exit_system()
        except KeyError,msg:
            print "Key error"+msg
            exit_system()
