import socket
import json
import sys
import os

#Socket listens for incoming connections and simply forwards all the messages to all the connections
class SocketServer():

    def __init__(self,port):
        self.HOST=self.get_host_name()#host name
        self.PORT=port#host port to bind to
        self.CONNECTIONS=[]#list of all connections
        self.MESSAGES={"greet":"GREETINGS","msg":"MESSAGES","incoming":"INCOMING"}#Type of Messages


    #UDP connection with proper Exception handling
    def create_UDP_connection(self):
        try:
            sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
            sock.bind((self.HOST,self.PORT))
        except socket.error, msg :
            print 'Failed to create socket. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
            exit_system()
            sock=None

        finally:
            return sock

    #host name with proper exception handling
    #query google DNS to get the host IP address - a way around to know the IP address
    def get_host_name(self):
        try:
            soc=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
            soc.connect(("8.8.8.8",80))
            host_name=soc.getsockname()[0]
        except socket.error,msg:
             print 'Failed to get Host Name. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
             exit_system()
             host_name=None
        finally:
            soc.close()
            return host_name

    #Return true if the address is already notes if not return False
    def is_address_noted(self,address):
        try:
            index=self.CONNECTIONS.index(address)
        except ValueError:
            index=-1

        if index >= 0:
            return True
        return False

    def listen_for_messages(self):
        connection=self.create_UDP_connection()
        print "Server running on "+self.HOST+" on PORT "+str(self.PORT)
        if connection is not None:
            while 1:
                data=connection.recvfrom(1024)
                if data is not None:
                    try:
                        msg=json.loads(data[0])
                    except TypeError,msg:
                         print 'TypeError. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
                         connection.close()
                         exit_system()
                    conn_address=data[1][0]
                    conn_port=data[1][1]
                    if msg["type"] == self.MESSAGES["greet"]:
                        if not self.is_address_noted((conn_address,conn_port)):
                            self.CONNECTIONS.append((conn_address,conn_port))
                    elif msg["type"] == self.MESSAGES["msg"]:
                        for con in self.CONNECTIONS:
                            print "Sending to ",con
                            try:
                                send_data=json.dumps({"type":self.MESSAGES["incoming"],
                                       "address":conn_address,
                                       "port":conn_port,
                                       "msg":msg["msg"]})
                            except TypeError,msg:
                                print 'TypeError. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
                                connection.close()
                                exit_system()
                            connection.sendto(send_data,con)


#Exit system handle multiple cases
#Global function so that it can be Used any where
def exit_system():
    try:
        sys.exit(0)
    except:
        os._exit(0)

#Conditions for port
#They cannot be negative and they cannot be out of known bounds
def check_ports(port):

    try:
        port=int(port)
    except:
        print "Port not an Integer"
        exit_system()
    if port < 0:
        print "Port cannot be Negative Number"
        exit_system()
    elif port > 65535:
        print "Port is out of bounds"
        exit_system()


if __name__=="__main__":

    args={}
    args_paras=[1]

    if len(sys.argv) < 3:
        print "Not enough arguments"
        exit_system()
    else:
        for i in args_paras:
            args[sys.argv[i]]=sys.argv[i+1]
        try:
            check_ports(args["-sp"])

            s=SocketServer(int(args["-sp"]))

            try:
                s.listen_for_messages()
            except KeyboardInterrupt:
                print "Keyboard Interrupt"
                exit_system()
        except KeyError,msg:
            print "No correct value for port: check if -sp argument is given"
            exit_system()
